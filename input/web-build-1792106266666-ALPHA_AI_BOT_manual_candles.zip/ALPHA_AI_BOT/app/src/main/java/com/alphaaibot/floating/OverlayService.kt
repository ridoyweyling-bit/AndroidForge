package com.alphaaibot.floating

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var floatingView: View? = null
    private var expanded = false
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "UPDATE_SIGNAL" && floatingView != null) redraw()
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showWidget()
    }

    private fun bg(color: Int, stroke: Int = Color.TRANSPARENT, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (stroke != Color.TRANSPARENT) setStroke(2, stroke)
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun showWidget() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(Color.rgb(8, 14, 24), Color.rgb(36, 101, 138), 20f)
            setPadding(12, 10, 12, 10)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = CandleLogoView(this).apply { contentDescription = "Candlestick logo; tap to expand or collapse" }
        header.addView(logo, LinearLayout.LayoutParams(38, 38))
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 0, 0, 0) }
        heading.addView(text("ALPHA AI BOT", 14f, Color.rgb(240, 247, 255), true))
        heading.addView(text("1 MIN · SIGNALS ONLY", 9f, Color.rgb(142, 168, 195)))
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = text(if (expanded) "−" else "⌄", 20f, Color.rgb(142, 168, 195), true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { expanded = !expanded; redraw() }
        }
        header.addView(toggle, LinearLayout.LayoutParams(26, 38))
        root.addView(header)
        logo.setOnClickListener { expanded = !expanded; redraw() }
        if (expanded) {
            val divider = View(this).apply { setBackgroundColor(Color.rgb(32, 49, 70)) }
            val dp = (resources.displayMetrics.density).toInt().coerceAtLeast(1)
            root.addView(divider, LinearLayout.LayoutParams(-1, dp))
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(2, 10, 2, 4)
            }
            row.addView(text("CURRENT SIGNAL", 10f, Color.rgb(145, 169, 194)), LinearLayout.LayoutParams(0, -2, 1f))
            val prefs = getSharedPreferences("alpha_signal", MODE_PRIVATE)
            val signal = prefs.getString("signal", "WAIT") ?: "WAIT"
            val signalColor = when (signal) {
                "CALL" -> Color.rgb(67, 230, 154)
                "PUT" -> Color.rgb(255, 105, 119)
                else -> Color.rgb(255, 211, 106)
            }
            val badgeBg = when (signal) {
                "CALL" -> Color.rgb(20, 57, 47)
                "PUT" -> Color.rgb(65, 34, 42)
                else -> Color.rgb(58, 51, 34)
            }
            val signalBadge = text(signal, 12f, signalColor, true).apply {
                gravity = Gravity.CENTER
                background = bg(badgeBg, Color.TRANSPARENT, 10f)
                setPadding(12, 6, 12, 6)
            }
            row.addView(signalBadge)
            root.addView(row)
            root.addView(text(prefs.getString("details", "Enter prices in the app to calculate a signal") ?: "Enter prices in the app to calculate a signal", 10f, Color.rgb(145, 169, 194)).apply {
                setPadding(2, 4, 2, 2)
            })
        }
        floatingView = root
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (resources.displayMetrics.widthPixels * 0.52f).toInt()
            y = (resources.displayMetrics.heightPixels * 0.18f).toInt()
        }
        makeDraggable(root)
        try { wm.addView(root, params) } catch (_: Exception) { stopSelf() }
    }

    private fun redraw() {
        val old = floatingView ?: return
        try { wm.removeView(old) } catch (_: Exception) {}
        floatingView = null
        showWidget()
    }

    private fun makeDraggable(view: View) {
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - touchX).toInt()
                    params.y = startY + (event.rawY - touchY).toInt()
                    try { wm.updateViewLayout(view, params) } catch (_: Exception) {}
                    true
                }
                else -> false
            }
        }
    }

    override fun onDestroy() {
        floatingView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        floatingView = null
        super.onDestroy()
    }
}
