package com.alphaaibot.floating

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 14, 24)
    private val cyan = Color.rgb(73, 216, 255)
    private val muted = Color.rgb(190, 207, 225)
    private lateinit var result: TextView
    private lateinit var details: TextView
    private lateinit var closes: List<EditText>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(label("ALPHA AI BOT", 27f, cyan, true, Gravity.CENTER))
        content.addView(label("MANUAL CANDLE MODE • 1 MINUTE", 12f, muted, true, Gravity.CENTER).apply {
            setPadding(0, 6, 0, 16)
        })
        content.addView(label("Enter the CLOSE price of each of the last 5 completed 1-minute candles, from oldest to newest.", 15f, muted, false, Gravity.CENTER))
        content.addView(label("Use the same price format shown on your Quotex chart. Do not enter commas inside a price.", 12f, Color.rgb(145, 169, 194), false, Gravity.CENTER).apply {
            setPadding(0, 8, 0, 14)
        })

        val names = listOf("Candle 1 — oldest", "Candle 2", "Candle 3", "Candle 4", "Candle 5 — newest")
        closes = names.map { name ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, 4, 0, 4)
            }
            row.addView(label(name, 14f, muted, false, Gravity.CENTER_VERTICAL), LinearLayout.LayoutParams(0, -2, 1f))
            val input = EditText(this).apply {
                hint = "e.g. 1.08452"
                setSingleLine(true)
                textSize = 15f
                setTextColor(Color.WHITE)
                setHintTextColor(Color.rgb(105, 126, 150))
                inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
                setPadding(12, 8, 12, 8)
                background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(Color.rgb(17, 28, 43)); cornerRadius = 12f; setStroke(1, Color.rgb(36, 101, 138))
                }
            }
            row.addView(input, LinearLayout.LayoutParams(dp(150), dp(48)))
            content.addView(row)
            input
        }

        val generate = Button(this).apply {
            text = "GENERATE RULE-BASED SIGNAL"
            setOnClickListener { calculateSignal() }
        }
        content.addView(generate, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12) })

        result = label("WAIT", 24f, Color.rgb(255, 211, 106), true, Gravity.CENTER).apply {
            setPadding(0, 18, 0, 6)
        }
        details = label("Enter five candle closes, then tap Generate.", 13f, muted, false, Gravity.CENTER)
        content.addView(result)
        content.addView(details.apply { setPadding(0, 0, 0, 12) })

        val enableOverlay = Button(this).apply {
            text = "ENABLE / SHOW FLOATING WIDGET"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        }
        content.addView(enableOverlay, LinearLayout.LayoutParams(-1, dp(50)))
        content.addView(label("Important: this is a simple educational price-momentum rule, not an AI prediction or a proven trading strategy. Manual inputs can be wrong, and signals can lose. No automatic trades are placed.", 12f, Color.rgb(145, 169, 194), false, Gravity.CENTER).apply {
            setPadding(0, 16, 0, 4)
        })

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        restoreSignal()
    }

    private fun calculateSignal() {
        val prices = closes.map { it.text.toString().trim().toDoubleOrNull() }
        if (prices.any { it == null || !it.isFinite() || it <= 0.0 }) {
            result.text = "WAIT"
            result.setTextColor(Color.rgb(255, 211, 106))
            details.text = "Please enter 5 valid positive close prices."
            return
        }
        val p = prices.filterNotNull()
        val moves = (1 until p.size).map { (p[it] - p[it - 1]) / p[it - 1] * 100.0 }
        val totalMove = (p.last() - p.first()) / p.first() * 100.0
        val upCount = moves.count { it > 0.0 }
        val downCount = moves.count { it < 0.0 }
        val signal = when {
            totalMove >= 0.08 && upCount >= 3 -> "CALL"
            totalMove <= -0.08 && downCount >= 3 -> "PUT"
            else -> "WAIT"
        }
        result.text = signal
        result.setTextColor(when (signal) {
            "CALL" -> Color.rgb(67, 230, 154)
            "PUT" -> Color.rgb(255, 105, 119)
            else -> Color.rgb(255, 211, 106)
        })
        details.text = "5-candle move: ${String.format(java.util.Locale.US, "%.4f", totalMove)}%  •  Up candles: $upCount  •  Down candles: $downCount\nRule: momentum ≥ 0.08% with 3+ rising steps = CALL; ≤ −0.08% with 3+ falling steps = PUT; otherwise WAIT."
        getSharedPreferences("alpha_signal", MODE_PRIVATE).edit()
            .putString("signal", signal)
            .putString("details", "5-candle move ${String.format(java.util.Locale.US, "%.4f", totalMove)}% · up $upCount / down $downCount")
            .putLong("updated", System.currentTimeMillis())
            .apply()
        if (Settings.canDrawOverlays(this)) {
            startService(Intent(this, OverlayService::class.java).setAction("UPDATE_SIGNAL"))
        }
    }

    private fun restoreSignal() {
        val prefs = getSharedPreferences("alpha_signal", MODE_PRIVATE)
        val signal = prefs.getString("signal", "WAIT") ?: "WAIT"
        result.text = signal
        result.setTextColor(when (signal) {
            "CALL" -> Color.rgb(67, 230, 154)
            "PUT" -> Color.rgb(255, 105, 119)
            else -> Color.rgb(255, 211, 106)
        })
        details.text = prefs.getString("details", "Enter five candle closes, then tap Generate.")
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean, gravityValue: Int): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        gravity = gravityValue
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
