package com.alphaaibot.floating

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.View

class CandleLogoView(context: Context) : View(context) {
    private val cyan = Color.rgb(73, 216, 255)
    private val blue = Color.rgb(77, 141, 255)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    init {
        background = GradientDrawable().apply {
            setColor(Color.rgb(16, 31, 48))
            cornerRadius = 14f * resources.displayMetrics.density
            setStroke((resources.displayMetrics.density).toInt().coerceAtLeast(1), Color.rgb(36, 101, 138))
        }
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        fun candle(x: Float, top: Float, bottom: Float, bodyTop: Float, bodyBottom: Float, color: Int) {
            paint.color = color
            paint.strokeWidth = 2f * d
            canvas.drawLine(x, top, x, bottom, paint)
            canvas.drawRoundRect(RectF(x - 4f*d, bodyTop, x + 4f*d, bodyBottom), 1.5f*d, 1.5f*d, paint)
        }
        val cx = width / 2f
        val cy = height / 2f
        candle(cx - 10*d, cy - 11*d, cy + 12*d, cy - 4*d, cy + 5*d, cyan)
        candle(cx, cy - 14*d, cy + 14*d, cy - 8*d, cy + 5*d, blue)
        candle(cx + 10*d, cy - 7*d, cy + 11*d, cy + 0*d, cy + 7*d, cyan)
    }
}
