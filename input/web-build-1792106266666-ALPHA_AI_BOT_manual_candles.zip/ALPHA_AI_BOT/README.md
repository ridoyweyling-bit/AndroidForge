# ALPHA AI BOT — floating widget source project

This is an Android Studio/AndroidIDE **source project**, not a prebuilt APK.
It creates a small draggable overlay with the candlestick logo. Tap the logo or chevron to expand/collapse it.

## Important limitations
- The widget currently displays **WAIT** because it is **not connected to Quotex candle/market data**.
- It does not produce real CALL/PUT predictions and does not execute trades.
- Do not use a displayed signal for real-money trading until a legitimate, verified market-data source and tested strategy are integrated.

## Build on an Android phone
1. Install a trusted Android IDE that can open Gradle Android projects (for example, AndroidIDE if available for your device), or open the project in Android Studio on a computer.
2. Extract this ZIP and open the `ALPHA_AI_BOT` project folder (the folder containing `settings.gradle`).
3. Allow Gradle to download the Android Gradle Plugin and dependencies when prompted; internet access is needed for the first build.
4. Build/install the debug APK from the IDE.
5. Open **ALPHA AI BOT**, tap **ENABLE FLOATING WIDGET**, and enable **Display over other apps** in Android settings.
6. Return to the app if needed. The small candle logo should float above other apps; tap it to expand/collapse and drag the panel to move it.

If Android's overlay permission screen opens, grant permission and return to the app, then tap the enable button again.
