# ALPHA AI BOT — automatic-mode UI source project

This is an Android source project, not a prebuilt APK. The app has a 1-minute automatic-mode screen, a market selector (normal forex, Quotex OTC, or both), and buttons to enable or disable the floating widget.

## Important market-data limitation
- Manual candle input has been removed.
- The app deliberately displays **WAIT — LIVE MARKET DATA NOT CONNECTED**. It does not generate fake/random CALL or PUT predictions.
- A compatible, reliable 1-minute candle feed must be integrated before automatic predictions can work for normal forex.
- Quotex OTC prices may not be available through public feeds and require a compatible source. Ordinary forex data must not be presented as matching OTC prices.
- The app does not execute trades. Any future signals must be tested and are not guaranteed profitable.

## Build
1. Upload this ZIP to your AndroidForge builder or open the extracted `ALPHA_AI_BOT` folder in a compatible Android IDE.
2. Build the debug APK.
3. Install it and open ALPHA AI BOT.
4. Tap **ENABLE FLOATING WIDGET** and grant overlay permission if prompted.
5. Tap **DISABLE FLOATING WIDGET** to hide/stop the overlay. Enable it again from the main app whenever needed.
