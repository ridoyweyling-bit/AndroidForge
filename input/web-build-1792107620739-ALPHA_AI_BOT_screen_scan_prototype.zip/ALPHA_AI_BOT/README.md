# ALPHA AI BOT — screen-scan prototype

Android floating overlay for on-demand, one-minute chart-screen checks. It does not execute trades.

## Build

Open this folder in an Android Gradle build service and build the debug APK. Java and Kotlin targets are both 17.

## Use

1. Install the APK and open ALPHA AI BOT.
2. Enable the floating widget (grant overlay permission when Android asks).
3. Tap **ENABLE SCREEN ANALYSIS** and approve Android's screen-capture prompt.
4. Return to Quotex and keep the chart visible.
5. Tap the floating candlestick logo to scan the current screen. Expand the panel to see the latest result.
6. Use **DISABLE FLOATING WIDGET** in the app to hide the overlay.

## Important limitations

This is an experimental screen-color heuristic, not OCR or a real candlestick recognizer. It counts red/green-like pixels in a fixed central screen region and may misread chart colors, UI elements, themes, and OTC displays. It is not validated and can produce incorrect UP/DOWN/WAIT outputs. It does not access Quotex internal data, does not guarantee prediction accuracy, and never places trades. Screen capture runs only after the user grants Android's system permission.
