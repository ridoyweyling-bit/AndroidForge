package com.alphaaibot.floating

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var floatingView: View? = null
    private var expanded = false
    private lateinit var params: WindowManager.LayoutParams
    private var projection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    @Volatile private var scanRequested = false
    private var hideBeforeScan = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            "START_CAPTURE" -> {
                startForegroundCompat()
                val resultCode = intent.getIntExtra("resultCode", 0)
                val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("resultData", Intent::class.java) else @Suppress("DEPRECATION") intent.getParcelableExtra("resultData")
                if (data != null) startCapture(resultCode, data)
            }
            "ANALYZE_SCREEN" -> analyzeScreen()
            "UPDATE_SIGNAL" -> if (floatingView != null) redraw()
            "STOP_CAPTURE" -> stopCapture()
        }
        if (floatingView == null && getSharedPreferences("alpha_signal", MODE_PRIVATE).getBoolean("floating_enabled", false)) {
            if (!::wm.isInitialized) wm = getSystemService(WINDOW_SERVICE) as WindowManager
            showWidget()
        }
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (getSharedPreferences("alpha_signal", MODE_PRIVATE).getBoolean("floating_enabled", false)) showWidget()
    }

    private fun startForegroundCompat() {
        val channelId = "alpha_screen_analysis"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "ALPHA screen analysis", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, channelId).setContentTitle("ALPHA AI BOT screen analysis").setContentText("Screen capture is active only for on-demand chart checks.").setSmallIcon(android.R.drawable.ic_menu_search).setContentIntent(open).setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("ALPHA AI BOT screen analysis").setContentText("Screen capture is active.").setSmallIcon(android.R.drawable.ic_menu_search).setContentIntent(open).build()
        }
        startForeground(45, notification)
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        stopCapture(removeForeground = false)
        try {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            val metrics = resources.displayMetrics
            val width = metrics.widthPixels
            val height = metrics.heightPixels
            val density = metrics.densityDpi
            captureThread = HandlerThread("AlphaScreenCapture").also { it.start() }
            captureHandler = Handler(captureThread!!.looper)
            imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 3)
            imageReader!!.setOnImageAvailableListener({ reader ->
                var image: Image? = null
                try {
                    image = reader.acquireLatestImage()
                    if (image != null && scanRequested) {
                        scanRequested = false
                        val (signal, detail) = inspectChartColors(image)
                        getSharedPreferences("alpha_signal", MODE_PRIVATE).edit()
                            .putString("signal", signal)
                            .putString("details", detail)
                            .putLong("updated", System.currentTimeMillis()).apply()
                        runOnMain { if (getSharedPreferences("alpha_signal", MODE_PRIVATE).getBoolean("floating_enabled", false)) redraw() }
                    }
                } catch (_: Exception) {
                    scanRequested = false
                    saveSignal("WAIT", "Screen analysis failed. Tap again and ensure the chart is visible.")
                } finally { image?.close() }
            }, captureHandler)
            projection!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopCapture() } }, captureHandler)
            virtualDisplay = projection!!.createVirtualDisplay("ALPHAChartCapture", width, height, density, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader!!.surface, null, captureHandler)
            saveSignal("WAIT", "Screen capture ready. Open Quotex and tap the floating logo to scan the visible chart.")
        } catch (_: Exception) {
            stopCapture()
            saveSignal("WAIT", "Screen capture could not start. Enable screen capture again in ALPHA AI BOT.")
        }
    }

    private fun analyzeScreen() {
        if (projection == null || imageReader == null) {
            val intent = Intent(this, MainActivity::class.java).setAction("SETUP_CAPTURE").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            startActivity(intent)
            return
        }
        scanRequested = true
        // Hide the overlay briefly so it does not cover the chart region in the captured frame.
        floatingView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        floatingView = null
        hideBeforeScan = true
        captureHandler?.postDelayed({
            if (scanRequested) {
                // The ImageReader callback handles the next frame. If no frame arrives, restore UI.
                captureHandler?.postDelayed({
                    if (scanRequested) {
                        scanRequested = false
                        saveSignal("WAIT", "No chart frame received. Tap again while Quotex is visible.")
                        runOnMain { if (getSharedPreferences("alpha_signal", MODE_PRIVATE).getBoolean("floating_enabled", false)) showWidget() }
                    }
                }, 1500)
            }
        }, 250)
    }

    private fun inspectChartColors(image: Image): Pair<String, String> {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val width = image.width
        val height = image.height
        var green = 0
        var red = 0
        // Approximate central chart area; this is a visual color heuristic, not candle/OCR recognition.
        val left = (width * 0.12f).toInt()
        val right = (width * 0.88f).toInt()
        val top = (height * 0.16f).toInt()
        val bottom = (height * 0.72f).toInt()
        val step = (width / 180).coerceAtLeast(3)
        var y = top
        while (y < bottom) {
            var x = left
            while (x < right) {
                val offset = y * rowStride + x * pixelStride
                if (offset + 2 < buffer.limit()) {
                    val r = buffer.get(offset).toInt() and 0xff
                    val g = buffer.get(offset + 1).toInt() and 0xff
                    val b = buffer.get(offset + 2).toInt() and 0xff
                    if (g > 85 && g > r * 1.28 && g > b * 1.08) green++
                    if (r > 100 && r > g * 1.28 && r > b * 1.12) red++
                }
                x += step
            }
            y += step
        }
        val total = green + red
        val signal = when {
            total < 12 -> "WAIT"
            green > red * 1.18 -> "UP"
            red > green * 1.18 -> "DOWN"
            else -> "WAIT"
        }
        val detail = "Screen-color heuristic only (green pixels: $green, red pixels: $red). Not a validated market prediction; check chart visibility and do not rely on this alone."
        return Pair(signal, detail)
    }

    private fun saveSignal(signal: String, details: String) {
        getSharedPreferences("alpha_signal", MODE_PRIVATE).edit().putString("signal", signal).putString("details", details).putLong("updated", System.currentTimeMillis()).apply()
    }

    private fun runOnMain(block: () -> Unit) { Handler(mainLooper).post(block) }

    private fun stopCapture(removeForeground: Boolean = true) {
        scanRequested = false
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { imageReader?.setOnImageAvailableListener(null, null); imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        try { captureThread?.quitSafely() } catch (_: Exception) {}
        captureThread = null
        captureHandler = null
        if (removeForeground) {
            if (Build.VERSION.SDK_INT >= 24) {
                try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
        }
    }

    private fun bg(color: Int, stroke: Int = Color.TRANSPARENT, radius: Float = 18f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius; if (stroke != Color.TRANSPARENT) setStroke(2, stroke)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER_VERTICAL
    }

    private fun showWidget() {
        if (floatingView != null || !getSharedPreferences("alpha_signal", MODE_PRIVATE).getBoolean("floating_enabled", false)) return
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(Color.rgb(8, 14, 24), Color.rgb(36, 101, 138), 20f); setPadding(12, 10, 12, 10) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = CandleLogoView(this).apply { contentDescription = "Tap to scan the visible chart" }
        header.addView(logo, LinearLayout.LayoutParams(38, 38))
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 0, 0, 0) }
        heading.addView(text("ALPHA AI BOT", 14f, Color.rgb(240, 247, 255), true))
        heading.addView(text("1 MIN · TAP TO SCAN", 9f, Color.rgb(142, 168, 195)))
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = text(if (expanded) "−" else "⌄", 20f, Color.rgb(142, 168, 195), true).apply { gravity = Gravity.CENTER; setOnClickListener { expanded = !expanded; redraw() } }
        header.addView(toggle, LinearLayout.LayoutParams(26, 38))
        root.addView(header)
        logo.setOnClickListener { analyzeScreen() }
        if (expanded) {
            root.addView(View(this).apply { setBackgroundColor(Color.rgb(32, 49, 70)) }, LinearLayout.LayoutParams(-1, dp(1)))
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(2, 10, 2, 4) }
            row.addView(text("LATEST RESULT", 10f, Color.rgb(145, 169, 194)), LinearLayout.LayoutParams(0, -2, 1f))
            val prefs = getSharedPreferences("alpha_signal", MODE_PRIVATE)
            val signal = prefs.getString("signal", "WAIT") ?: "WAIT"
            val signalColor = when (signal) { "UP" -> Color.rgb(67, 230, 154); "DOWN" -> Color.rgb(255, 105, 119); else -> Color.rgb(255, 211, 106) }
            val badgeBg = when (signal) { "UP" -> Color.rgb(20, 57, 47); "DOWN" -> Color.rgb(65, 34, 42); else -> Color.rgb(58, 51, 34) }
            row.addView(text(signal, 14f, signalColor, true).apply { gravity = Gravity.CENTER; background = bg(badgeBg, Color.TRANSPARENT, 10f); setPadding(12, 6, 12, 6) })
            root.addView(row)
            root.addView(text(prefs.getString("details", "Enable screen analysis in the app") ?: "Enable screen analysis in the app", 10f, Color.rgb(145, 169, 194)).apply { setPadding(2, 4, 2, 2) })
        }
        floatingView = root
        params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = (resources.displayMetrics.widthPixels * 0.52f).toInt(); y = (resources.displayMetrics.heightPixels * 0.18f).toInt()
        }
        makeDraggable(root)
        try { wm.addView(root, params) } catch (_: Exception) { floatingView = null }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun redraw() { val old = floatingView ?: return; try { wm.removeView(old) } catch (_: Exception) {}; floatingView = null; showWidget() }

    private fun makeDraggable(view: View) {
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        view.setOnTouchListener { _, event -> when (event.action) {
            MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = event.rawX; touchY = event.rawY; true }
            MotionEvent.ACTION_MOVE -> { params.x = startX + (event.rawX - touchX).toInt(); params.y = startY + (event.rawY - touchY).toInt(); try { wm.updateViewLayout(view, params) } catch (_: Exception) {}; true }
            else -> false
        } }
    }

    override fun onDestroy() {
        floatingView?.let { try { wm.removeView(it) } catch (_: Exception) {} }; floatingView = null
        stopCapture()
        super.onDestroy()
    }
}
