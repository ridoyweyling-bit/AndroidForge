package com.alphaaibot.floating

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 14, 24)
    private val cyan = Color.rgb(73, 216, 255)
    private val muted = Color.rgb(190, 207, 225)
    private lateinit var result: TextView
    private lateinit var details: TextView
    private lateinit var marketPicker: Spinner
    private val screenCaptureRequest = 2401

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(label("ALPHA AI BOT", 27f, cyan, true, Gravity.CENTER))
        content.addView(label("AUTOMATIC MODE • 1 MINUTE", 12f, muted, true, Gravity.CENTER).apply {
            setPadding(0, 6, 0, 18)
        })
        content.addView(label("Manual candle entry has been removed.", 16f, muted, false, Gravity.CENTER).apply {
            setPadding(0, 4, 0, 12)
        })
        content.addView(label("Choose your market", 14f, muted, true, Gravity.START).apply {
            setPadding(0, 8, 0, 6)
        })
        marketPicker = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Both Forex and OTC", "Normal Forex only", "Quotex OTC only"))
            setSelection(0)
        }
        content.addView(marketPicker, LinearLayout.LayoutParams(-1, dp(48)))

        result = label("WAIT", 27f, Color.rgb(255, 211, 106), true, Gravity.CENTER).apply {
            setPadding(0, 22, 0, 6)
        }
        details = label("LIVE MARKET DATA NOT CONNECTED\nAutomatic CALL/PUT signals are unavailable until a compatible candle feed is connected.", 14f, muted, false, Gravity.CENTER).apply {
            setPadding(0, 0, 0, 18)
        }
        content.addView(result)
        content.addView(details)

        val refresh = Button(this).apply {
            text = "CHECK SIGNAL STATUS"
            setOnClickListener { updateStatus() }
        }
        content.addView(refresh, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(10) })

        val enableScreenAnalysis = Button(this).apply {
            text = "ENABLE SCREEN ANALYSIS"
            setOnClickListener { requestScreenCapture() }
        }
        content.addView(enableScreenAnalysis, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(10) })

        val enableOverlay = Button(this).apply {
            text = "ENABLE FLOATING WIDGET"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    getSharedPreferences("alpha_signal", MODE_PRIVATE).edit().putBoolean("floating_enabled", true).apply()
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                }
            }
        }
        content.addView(enableOverlay, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(10) })

        val disableOverlay = Button(this).apply {
            text = "DISABLE FLOATING WIDGET"
            setOnClickListener {
                getSharedPreferences("alpha_signal", MODE_PRIVATE).edit().putBoolean("floating_enabled", false).apply()
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        }
        content.addView(disableOverlay, LinearLayout.LayoutParams(-1, dp(50)))

        content.addView(label("Screen analysis uses a rough red/green pixel heuristic from the visible chart. It is not candle recognition, is not validated, and may be wrong. Allow screen capture, return to Quotex, then tap the floating logo to scan. No trades are executed automatically.", 12f, Color.rgb(145, 169, 194), false, Gravity.CENTER).apply {
            setPadding(0, 16, 0, 4)
        })

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        updateStatus()
        if (intent?.action == "SETUP_CAPTURE") requestScreenCapture()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.action == "SETUP_CAPTURE") requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), screenCaptureRequest)
    }

    @Deprecated("Deprecated in Android API; required for compatibility with this simple project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == screenCaptureRequest) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, OverlayService::class.java).apply {
                    action = "START_CAPTURE"
                    putExtra("resultCode", resultCode)
                    putExtra("resultData", data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent) else startService(serviceIntent)
                details.text = "Screen capture enabled. Return to Quotex and tap the floating logo to scan the visible chart."
            } else {
                details.text = "Screen capture permission was cancelled. Tap ENABLE SCREEN ANALYSIS to try again."
            }
        }
    }

    private fun updateStatus() {
        result.text = "WAIT"
        result.setTextColor(Color.rgb(255, 211, 106))
        val market = marketPicker.selectedItem?.toString() ?: "Both Forex and OTC"
        details.text = "Market: $market\nTap ENABLE SCREEN ANALYSIS and allow capture. Return to Quotex and tap the floating logo to scan. Results use a rough screen-color heuristic and can be wrong."
        getSharedPreferences("alpha_signal", MODE_PRIVATE).edit()
            .putString("signal", "WAIT")
            .putString("details", "Enable screen analysis, then tap the floating logo while Quotex is visible.")
            .putLong("updated", System.currentTimeMillis())
            .apply()
        if (Settings.canDrawOverlays(this) && getSharedPreferences("alpha_signal", MODE_PRIVATE).getBoolean("floating_enabled", false)) {
            startService(Intent(this, OverlayService::class.java).setAction("UPDATE_SIGNAL"))
        }
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean, gravityValue: Int): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        gravity = gravityValue
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
