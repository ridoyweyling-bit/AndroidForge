package com.alphaaibot.floating

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 14, 24)
        window.navigationBarColor = Color.rgb(8, 14, 24)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(8, 14, 24))
        }
        val title = TextView(this).apply {
            text = "ALPHA AI BOT"
            textSize = 26f
            setTextColor(Color.rgb(73, 216, 255))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Compact floating candlestick widget\n\nSignals only • 1-minute display\nNo automatic trading\n\nImportant: live Quotex market data is not connected. The widget will show WAIT until a real, verified data feed is added."
            textSize = 15f
            setTextColor(Color.rgb(190, 207, 225))
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val button = Button(this).apply {
            text = "ENABLE FLOATING WIDGET"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    startActivity(intent)
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    finish()
                }
            }
        }
        root.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(button, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this) && intent.getBooleanExtra("start_overlay", false)) {
            startService(Intent(this, OverlayService::class.java))
            finish()
        }
    }
}
